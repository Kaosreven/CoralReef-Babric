package com.primetoxinz.coralreef.block;

import com.primetoxinz.coralreef.listener.CommonListener;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_15;
import net.minecraft.class_17;
import net.minecraft.class_18;
import net.minecraft.class_25;
import net.modificationstation.stationapi.api.template.block.TemplateBlock;
import net.modificationstation.stationapi.api.util.Identifier;

import java.util.Random;

public class CoralBlock extends TemplateBlock {

    public CoralBlock(Identifier id) {
        super(id, class_15.field_985);
        setTranslationKey(id);
        method_1587(0.0f);
        method_1577(1.0f);
        method_1590(0);
        method_1584(true);
    }

    @Override
    public boolean method_1567(class_18 level, int x, int y, int z) {
        int below = level.method_1776(x, y - 1, z);
        return CommonListener.REEF1 != null &&
               below == CommonListener.REEF1.field_1915 &&
               isAdjacentToWater(level, x, y, z);
    }

    @Override
    public void method_1609(class_18 level, int x, int y, int z, int id) {
        super.method_1609(level, x, y, z, id);
        if (!canSurvive(level, x, y, z)) {
            method_1592(level, x, y, z, level.method_1778(x, y, z));
            level.method_229(x, y, z, 0);
        }
    }

    @Override
    public void method_1630(class_18 level, int x, int y, int z) {
        super.method_1630(level, x, y, z);
        if (isAdjacentToWater(level, x, y, z)) {
            level.method_229(x, y, z, class_17.field_1823.field_1915);
        }
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_1617(class_18 level, int x, int y, int z, Random rand) {
        if (level.method_1779(x, y + 1, z) == class_15.field_985) {
            for (int i = 0; i < 4; i++) {
                double bx = x + rand.nextDouble();
                double by = y + rand.nextDouble();
                double bz = z + rand.nextDouble();
                level.method_178("bubble", bx, by, bz, 0.0, 0.04, 0.0);
            }
        }
    }

    protected boolean canSurvive(class_18 level, int x, int y, int z) {
        int below = level.method_1776(x, y - 1, z);
        return CommonListener.REEF1 != null &&
               below == CommonListener.REEF1.field_1915 &&
               isAdjacentToWater(level, x, y, z);
    }

    protected boolean isAdjacentToWater(class_18 level, int x, int y, int z) {
        return level.method_1779(x + 1, y, z) == class_15.field_985
            || level.method_1779(x - 1, y, z) == class_15.field_985
            || level.method_1779(x, y, z + 1) == class_15.field_985
            || level.method_1779(x, y, z - 1) == class_15.field_985
            || level.method_1779(x, y + 1, z) == class_15.field_985;
    }

    @Override
    public class_25 method_1624(class_18 level, int x, int y, int z) {
        return null;
    }

    @Override
    public boolean method_1620() {
        return false;
    }

    @Override
    public boolean method_1623() {
        return false;
    }

    @Override
    @Environment(EnvType.CLIENT)
    public int method_1621() {
        return 1;
    }
}
