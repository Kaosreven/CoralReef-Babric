package com.primetoxinz.coralreef.block;

import net.minecraft.class_15;
import net.modificationstation.stationapi.api.template.block.TemplateBlock;
import net.modificationstation.stationapi.api.util.Identifier;

public class ReefBlock extends TemplateBlock {
    public ReefBlock(Identifier id) {
        super(id, class_15.field_983);
        setTranslationKey(id);
        method_1587(1.5f);
    }
}
