package com.primetoxinz.coralreef.block;

import com.primetoxinz.coralreef.listener.CommonListener;
import net.minecraft.class_15;
import net.minecraft.class_18;
import net.modificationstation.stationapi.api.util.Identifier;

import java.util.Random;

public class GrowableCoralBlock extends CoralBlock {
    private final int maxHeight;

    public GrowableCoralBlock(Identifier id, int maxHeight) {
        super(id);
        this.maxHeight = maxHeight;
        method_1584(true);
    }

    @Override
    public boolean method_1567(class_18 level, int x, int y, int z) {
        int below = level.method_1776(x, y - 1, z);
        if (CommonListener.REEF1 != null && below == CommonListener.REEF1.field_1915) {
            return isAdjacentToWater(level, x, y, z);
        }
        return below == this.field_1915 && isAdjacentToWater(level, x, y, z);
    }

    @Override
    protected boolean canSurvive(class_18 level, int x, int y, int z) {
        int below = level.method_1776(x, y - 1, z);
        boolean validBase = (CommonListener.REEF1 != null && below == CommonListener.REEF1.field_1915)
                         || below == this.field_1915;
        return validBase && isAdjacentToWater(level, x, y, z);
    }

    @Override
    public void method_1602(class_18 level, int x, int y, int z, Random rand) {
        if (!canSurvive(level, x, y, z)) {
            method_1592(level, x, y, z, 0);
            level.method_229(x, y, z, 0);
            return;
        }
        // grow upward if there's water above and height limit not reached
        if (level.method_1779(x, y + 1, z) == class_15.field_985) {
            int height = 1;
            while (height < maxHeight && level.method_1776(x, y - height, z) == this.field_1915) {
                height++;
            }
            if (height < maxHeight) {
                int meta = level.method_1778(x, y, z);
                if (meta >= 15) {
                    level.method_229(x, y + 1, z, this.field_1915);
                    level.method_215(x, y, z, 0);
                } else {
                    level.method_215(x, y, z, meta + 1);
                }
            }
        }
    }
}
