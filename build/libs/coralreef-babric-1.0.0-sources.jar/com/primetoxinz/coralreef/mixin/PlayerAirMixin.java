package com.primetoxinz.coralreef.mixin;

import com.primetoxinz.coralreef.listener.CommonListener;
import net.minecraft.class_17;
import net.minecraft.class_54;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_54.class)
public class PlayerAirMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void restoreAirNearCoral(CallbackInfo ci) {
        class_54 player = (class_54)(Object)this;
        if (player.field_1596 == null || CommonListener.CORALS.isEmpty()) return;

        int px = (int) Math.floor(player.field_1600);
        int py = (int) Math.floor(player.field_1601);
        int pz = (int) Math.floor(player.field_1602);

        for (int dx = -2; dx <= 2; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -2; dz <= 2; dz++) {
                    int blockId = player.field_1596.method_1776(px + dx, py + dy, pz + dz);
                    for (class_17 coral : CommonListener.CORALS) {
                        if (blockId == coral.field_1915) {
                            player.field_1614 = 300;
                            return;
                        }
                    }
                }
            }
        }
    }
}
