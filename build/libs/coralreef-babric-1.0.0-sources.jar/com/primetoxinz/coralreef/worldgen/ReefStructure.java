package com.primetoxinz.coralreef.worldgen;

import java.util.List;
import java.util.Random;
import net.minecraft.class_15;
import net.minecraft.class_17;
import net.minecraft.class_18;
import net.minecraft.class_239;

public class ReefStructure extends class_239 {
    private final class_17 reefBase;
    private final class_17 reefRock;
    private final List<class_17> corals;

    public ReefStructure(class_17 reefBase, class_17 reefRock, List<class_17> corals) {
        this.reefBase = reefBase;
        this.reefRock = reefRock;
        this.corals = corals;
    }

    @Override
    public boolean method_1142(class_18 level, Random rand, int x, int y, int z) {
        int floorY = findOceanFloor(level, x, z);
        if (floorY < 0) return false;

        int radius = 3 + rand.nextInt(4);
        boolean placed = false;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius) continue;

                int wx = x + dx, wz = z + dz;
                int localFloor = findOceanFloor(level, wx, wz);
                if (localFloor < 0) continue;

                int blockId = level.method_1776(wx, localFloor, wz);
                if (canReplace(blockId)) {
                    level.method_229(wx, localFloor, wz, reefBase.field_1915);
                    placed = true;

                    // Place coral if two water blocks exist above the reef
                    if (!corals.isEmpty()
                            && isWater(level, wx, localFloor + 1, wz)
                            && isWater(level, wx, localFloor + 2, wz)
                            && rand.nextDouble() < 0.4) {
                        class_17 coral = corals.get(rand.nextInt(corals.size()));
                        level.method_229(wx, localFloor + 1, wz, coral.field_1915);
                    }
                }
            }
        }

        // Scatter a few reef rock formations in and around the disk
        for (int i = 0; i < 3; i++) {
            int rx = x + rand.nextInt(radius * 2 + 1) - radius;
            int rz = z + rand.nextInt(radius * 2 + 1) - radius;
            int rFloor = findOceanFloor(level, rx, rz);
            if (rFloor >= 0) {
                placeRock(level, rand, rx, rFloor, rz);
            }
        }

        return placed;
    }

    private void placeRock(class_18 level, Random rand, int x, int y, int z) {
        int size = 1 + rand.nextInt(2);
        for (int dx = -size; dx <= size; dx++) {
            for (int dy = 0; dy <= size; dy++) {
                for (int dz = -size; dz <= size; dz++) {
                    if (dx * dx + dy * dy + dz * dz <= size * size) {
                        int wx = x + dx, wy = y + dy, wz = z + dz;
                        if (isWater(level, wx, wy, wz)) {
                            level.method_229(wx, wy, wz, reefRock.field_1915);
                        }
                    }
                }
            }
        }
    }

    private int findOceanFloor(class_18 level, int x, int z) {
        for (int y = 60; y > 5; y--) {
            int id = level.method_1776(x, y, z);
            if (!isWaterOrAir(id)) {
                // solid block — check if the block above is water (i.e., we're underwater)
                if (level.method_1779(x, y + 1, z) == class_15.field_985) {
                    return y;
                }
                return -1;
            }
        }
        return -1;
    }

    private boolean isWater(class_18 level, int x, int y, int z) {
        return level.method_1779(x, y, z) == class_15.field_985;
    }

    private boolean isWaterOrAir(int id) {
        return id == 0
            || id == class_17.field_1822.field_1915
            || id == class_17.field_1823.field_1915;
    }

    private boolean canReplace(int id) {
        return id == class_17.field_1826.field_1915
            || id == class_17.field_1827.field_1915
            || id == class_17.field_1947.field_1915;
    }
}
